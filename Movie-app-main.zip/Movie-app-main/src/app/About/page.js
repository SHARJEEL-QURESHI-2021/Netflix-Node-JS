import React from 'react'
import Herosection from '../component/Herosection'

export default function  About(){
  return (
    <Herosection title="OUR STORY"/>
  )
}

