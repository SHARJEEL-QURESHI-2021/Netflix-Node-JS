
import Herosection from "./component/Herosection"
export default function Home() {
  return (
    <main className="">
    
<Herosection title="LET'S WATCH MOVIE TOGETHER"/>

          </main>
  )
}
