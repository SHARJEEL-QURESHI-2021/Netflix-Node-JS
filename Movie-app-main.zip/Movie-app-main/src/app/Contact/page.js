import React from 'react'
import ContactCards from '../component/ContactCards'
export default  function Contact(){
  return (
    <>
    
    <ContactCards/>
    </>
  )
}

